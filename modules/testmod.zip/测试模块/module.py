# -*- coding: utf-8 -*-
"""仓库测试模块 —— 用来验证"从模块仓库下载模块"这条路能不能走通。"""
KEY = "testmod"
NAME = "测试模块"
DESC = "仓库测试用；可直接删除"
VERSION = "1.0"
BUILTIN = False
ORDER = 99
