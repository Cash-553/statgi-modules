# -*- coding: utf-8 -*-
"""极简界面：只加一行开关（构建失败也不会影响程序）。"""
from PySide6.QtWidgets import QWidget

import qt_theme as T
from qt_widgets import SettingRow, Switch, bind_cb


def desc(tab):
    return "仓库测试用；确认能下载、能被识别，之后可以直接删掉"


def build(tab):
    try:
        tab.switch_testmod = Switch(tab, bool((tab._c.get("modules") or {}).get(
            "testmod", False)))
        tab.switch_testmod.toggled.connect(bind_cb(tab._on_behavior))
        tab.row_testmod = SettingRow(
            tab, "box", "测试模块", desc(tab), tab.switch_testmod,
            alpha=tab.alpha,
            tip="这是从模块仓库下载来的测试模块。\n"
                "看到这张卡片 = 仓库下载、识别、界面加载 全部正常 ✓\n"
                "不需要了：删掉 modules\\testmod\\ 文件夹即可。")
        tab.add_card(tab.row_testmod)
        box = QWidget()
        return {"key": "testmod", "card": tab.row_testmod, "box": box,
                "switch": tab.switch_testmod,
                "uninstall_card": None}
    except Exception as e:      # 出错也别影响程序
        print("[测试模块] 界面构建失败：", type(e).__name__, e, flush=True)
        return None


def collect(tab, c):
    return c
